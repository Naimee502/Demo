package com.an.room;

import android.app.Application;

public class AppController extends Application {


}
